# ------------------ IMPORTS ------------------
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Sum
from django.db import transaction
from .models import Team, Participant, Attendance, Submission, Evaluation


# ------------------ HOME ------------------
def home(request):
    """Public landing page."""
    return render(request, 'home.html')


# ------------------ LOGIN ------------------
def login_view(request):
    """Handles admin and team login with disqualification warning."""
    storage = messages.get_messages(request)
    for _ in storage:
        pass

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Admin login
        if username == 'admin' and password == 'admin123':
            return redirect('admin_dashboard')

        # Team login
        try:
            team = Team.objects.get(team_name=username, password=password)
            request.session['team_id'] = team.id
            request.session['team_name'] = team.team_name

            if not team.qualified:
                messages.warning(
                    request,
                    f"⚠️ {team.team_name}, your team has been disqualified due to attendance issues. "
                    "You can still view your evaluations and feedback."
                )

            return redirect('team_dashboard', team_name=team.team_name)

        except Team.DoesNotExist:
            messages.error(request, "Invalid credentials. Please try again.")

    return render(request, 'login.html')


# ------------------ TEAM DASHBOARD ------------------
def team_dashboard(request, team_name):
    """Displays team dashboard with evaluations and submissions."""
    team = get_object_or_404(Team, team_name=team_name)
    evaluations = Evaluation.objects.filter(team=team)
    submissions = Submission.objects.filter(team=team)

    return render(request, 'team_dashboard.html', {
        'team': team,
        'evaluations': evaluations,
        'submissions': submissions,
    })


# ------------------ ADMIN DASHBOARD ------------------
@staff_member_required
def admin_dashboard(request):
    """Displays admin overview with statistics."""
    total_teams = Team.objects.count()
    qualified = Team.objects.filter(qualified=True).count()
    disqualified = Team.objects.filter(qualified=False).count()
    submission_count = Submission.objects.count()

    top3 = (
        Team.objects.annotate(total_score=Sum('evaluation__score'))
        .order_by('-total_score')[:3]
    )

    return render(request, 'admin_dashboard.html', {
        'total_teams': total_teams,
        'qualified': qualified,
        'disqualified': disqualified,
        'submission_count': submission_count,
        'top3': top3,
    })


# ------------------ TEAM MANAGEMENT ------------------
@staff_member_required
def team_management(request):
    """Admin view to manage teams and participants."""
    teams = Team.objects.prefetch_related('participants').all()
    for team in teams:
        team.stack_list = (
            [tech.strip() for tech in team.project_stack.split(',')]
            if team.project_stack else []
        )
    return render(request, 'team_management.html', {'teams': teams})


# ------------------ ATTENDANCE PAGE (MULTIPLE SAVE FIXED) ------------------
@staff_member_required
def attendance_page(request):
    """
    Robust attendance save + immediate render:
    - Accepts both "attendance_<teamid>_<week>" and "week<week>_<teamid>" keys.
    - Normalizes incoming values strictly.
    - Saves Attendance rows in DB.
    - Updates Team qualification in DB.
    - Instead of redirect, re-renders page with authoritative status_map (so UI matches DB immediately).
    - Prints debug info to runserver console to inspect what was received and saved.
    """
    teams = Team.objects.all().order_by("team_number")

    def normalize_raw_to_bool(raw):
        if raw is None:
            return None
        s = str(raw).strip().lower()
        if s in ("present", "p", "1", "true", "yes", "y"):
            return True
        if s in ("absent", "a", "0", "false", "no", "n") or "abs" in s:
            return False
        # fallback: treat unknown as None (so we preserve DB value) but log
        return None

    if request.method == "POST":
        try:
            with transaction.atomic():
                print("\n=== Attendance POST received ===")
                # Keep track of teams that we changed (for debug)
                changed_teams = set()

                for team in teams:
                    print(f"-- Team {team.id} ({team.team_name}) --")
                    for week in range(1, 6):
                        key_attendance = f"attendance_{team.id}_{week}"
                        key_week = f"week{week}_{team.id}"

                        raw = None
                        if key_attendance in request.POST:
                            raw = request.POST.get(key_attendance)
                        elif key_week in request.POST:
                            raw = request.POST.get(key_week)
                        else:
                            # maybe old template used different names or JS removed fields;
                            # we'll still try to look for any POST keys that contain team id & week
                            # (last resort)
                            for k, v in request.POST.items():
                                if f"{team.id}" in k and f"{week}" in k and isinstance(v, str):
                                    raw = v
                                    break

                        print(f"  week {week}: raw -> {raw!r}")

                        norm = normalize_raw_to_bool(raw)
                        if norm is None:
                            # preserve existing DB value; ensure record exists
                            Attendance.objects.get_or_create(team=team, week=week)
                            continue

                        # check existing record to avoid unnecessary writes (and track changes)
                        att_obj, created = Attendance.objects.get_or_create(team=team, week=week)
                        if att_obj.is_present != norm or created:
                            att_obj.is_present = norm
                            att_obj.save()
                            changed_teams.add(team.id)
                            print(f"    -> saved: week {week} is_present={norm} (created={created})")

                # After all attendance rows updated, update team qualification from DB
                for team in teams:
                    # recompute from DB authoritative source
                    team.update_qualification(save_to_db=True)
                    print(f"  Team {team.id} after recompute -> qualified={team.qualified}, reason={team.disqualification_reason!r}")

                print("=== End Attendance POST ===\n")
                messages.success(request, "✅ Attendance saved. Page refreshed with authoritative DB values.")

        except Exception as e:
            print("ERROR while saving attendance:", repr(e))
            messages.error(request, f"⚠️ Error while saving attendance: {e}")

        # NOTE: we render the page directly here (no redirect) so the response you see right away
        # reflects what was just saved to DB.
    
    # Build attendance_data fresh from DB
    attendance_data = {}
    for team in teams:
        week_data = {}
        for week in range(1, 6):
            record, _ = Attendance.objects.get_or_create(team=team, week=week)
            week_data[str(week)] = "present" if record.is_present else "absent"
        attendance_data[str(team.id)] = week_data  # use string keys to match template filters

    # Build authoritative status_map from DB attendance (string keys)
    status_map = {}
    for team in teams:
        is_disq = Attendance.objects.filter(team=team, is_present=False).exists()
        status_map[str(team.id)] = (not is_disq)
        # also update in-memory team (optional)
        team.qualified = status_map[str(team.id)]

    return render(request, "attendance_page.html", {
        "teams": teams,
        "attendance_data": attendance_data,
        "status_map": status_map,
    })

# ------------------ EVALUATION PAGE ------------------
@staff_member_required
def evaluation_page(request):
    """Admin page for weekly evaluations."""
    teams = Team.objects.all().order_by("team_number")
    criteria_fields = ["presentation", "communication", "teamwork", "improvement"]

    if request.method == 'POST':
        team_id = request.POST.get('team_id')
        if not team_id:
            messages.error(request, "⚠️ No team selected.")
            return redirect('evaluation_page')

        team = get_object_or_404(Team, id=team_id)

        if not team.qualified:
            messages.error(request, f"🚫 {team.team_name} is disqualified — evaluation disabled.")
            return redirect('evaluation_page')

        def safe_int(v):
            try:
                return int(v)
            except (TypeError, ValueError):
                return 0

        update_data = {}
        for week in range(1, 6):
            total = 0
            for field in criteria_fields:
                key = f"week{week}_{field}"
                val = safe_int(request.POST.get(key))
                update_data[key] = val
                total += val
            update_data[f"week{week}_feedback"] = request.POST.get(f"week{week}_feedback", "")
            update_data[f"week{week}_total"] = total

        update_data["overall_feedback"] = request.POST.get("overall_feedback", "")
        update_data["score"] = sum(update_data[f"week{w}_total"] for w in range(1, 6))

        Evaluation.objects.update_or_create(team=team, defaults=update_data)

        messages.success(request, f"✅ Evaluation saved for {team.team_name} (Total Score: {update_data['score']})")
        return redirect('evaluation_page')

    # ---- Load evaluations ----
    team_evaluations = []
    for team in teams:
        eval_obj = Evaluation.objects.filter(team=team).first()
        eval_data = {}
        if eval_obj:
            for week in range(1, 6):
                for field in criteria_fields:
                    eval_data[f"week{week}_{field}"] = getattr(eval_obj, f"week{week}_{field}", 0)
                eval_data[f"week{week}_feedback"] = getattr(eval_obj, f"week{week}_feedback", "")
                eval_data[f"week{week}_total"] = getattr(eval_obj, f"week{week}_total", 0)
            eval_data["overall_feedback"] = getattr(eval_obj, "overall_feedback", "")
            eval_data["score"] = getattr(eval_obj, "score", 0)
        else:
            for week in range(1, 6):
                for field in criteria_fields:
                    eval_data[f"week{week}_{field}"] = 0
                eval_data[f"week{week}_feedback"] = ""
                eval_data[f"week{week}_total"] = 0
            eval_data["overall_feedback"] = ""
            eval_data["score"] = 0

        team_evaluations.append({"team": team, "evaluation": eval_data})

    return render(request, "evaluation_page.html", {
        "team_evaluations": team_evaluations,
        "criteria_fields": criteria_fields,
    })
