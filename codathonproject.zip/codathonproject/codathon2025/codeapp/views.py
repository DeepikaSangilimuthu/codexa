# ------------------ IMPORTS ------------------
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Sum
from .models import Team, Participant, Attendance, Submission, Evaluation


# ------------------ HOME ------------------
def home(request):
    return render(request, 'home.html')


# ------------------ LOGIN ------------------
def login_view(request):
    """
    Handles both admin and team logins.
    Allows disqualified teams to log in but shows a warning on dashboard.
    """
    # Clear old messages
    storage = messages.get_messages(request)
    for _ in storage:
        pass

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # 🧠 Admin login
        if username == 'admin' and password == 'admin123':
            return redirect('admin_dashboard')

        # 🧠 Team login
        try:
            team = Team.objects.get(team_name=username, password=password)

            # Save session
            request.session['team_id'] = team.id
            request.session['team_name'] = team.team_name

            # ✅ Allow disqualified team login but show message
            if not team.qualified:
                messages.warning(
                    request,
                    f"⚠️ {team.team_name}, your team has been disqualified due to attendance issues. "
                    "You can still view your evaluations and feedback."
                )

            return redirect('team_dashboard', team_name=team.team_name)

        except Team.DoesNotExist:
            messages.error(request, "Invalid credentials. Please try again.")

    return render(request, 'login.html')


# ------------------ TEAM DASHBOARD ------------------
def team_dashboard(request, team_name):
    """
    Team dashboard — shows attendance, feedback, and project data.
    Disqualified teams can still log in but see a warning banner.
    """
    team = get_object_or_404(Team, team_name=team_name)
    evaluations = Evaluation.objects.filter(team=team)
    submissions = Submission.objects.filter(team=team)

    # Show warning if disqualified
   

    context = {
        'team': team,
        'evaluations': evaluations,
        'submissions': submissions,
    }
    return render(request, 'team_dashboard.html', context)


# ------------------ ADMIN DASHBOARD ------------------
@staff_member_required
def admin_dashboard(request):
    """
    Admin summary dashboard — shows team stats and top 3 by score.
    """
    total_teams = Team.objects.count()
    qualified = Team.objects.filter(qualified=True).count()
    disqualified = Team.objects.filter(qualified=False).count()
    submission_count = Submission.objects.count()

    top3 = (
        Team.objects.annotate(total_score=Sum('evaluation__score'))
        .order_by('-total_score')[:3]
    )

    context = {
        'total_teams': total_teams,
        'qualified': qualified,
        'disqualified': disqualified,
        'submission_count': submission_count,
        'top3': top3,
    }
    return render(request, 'admin_dashboard.html', context)


# ------------------ TEAM MANAGEMENT ------------------
@staff_member_required
def team_management(request):
    """
    Admin view for managing teams and participants.
    """
    teams = Team.objects.prefetch_related('participants').all()

    for team in teams:
        team.stack_list = (
            [tech.strip() for tech in team.project_stack.split(',')]
            if team.project_stack else []
        )

    return render(request, 'team_management.html', {'teams': teams})


# ------------------ ATTENDANCE PAGE ------------------
@staff_member_required
def attendance_page(request):
    """
    Admin can mark weekly attendance.
    Multiple teams can be disqualified at once.
    If any week is 'absent', the team is automatically disqualified.
    """
    teams = Team.objects.all()

    if request.method == "POST":
        for team in teams:
            # Fetch week's attendance for each team
            team.week1 = request.POST.get(f"week1_{team.id}", team.week1)
            team.week2 = request.POST.get(f"week2_{team.id}", team.week2)
            team.week3 = request.POST.get(f"week3_{team.id}", team.week3)
            team.week4 = request.POST.get(f"week4_{team.id}", team.week4)
            team.week5 = request.POST.get(f"week5_{team.id}", team.week5)

            # ✅ Automatically disqualify if any week = absent
            if any(
                getattr(team, f"week{i}") == "absent"
                for i in range(1, 6)
            ):
                team.qualified = False
                team.disqualification_reason = "Absent in one or more weeks."
            else:
                team.qualified = True
                team.disqualification_reason = ""

            team.save()

        messages.success(request, "✅ Attendance updated successfully for all teams!")
        return redirect("attendance_page")

    return render(request, "attendance_page.html", {"teams": teams})


# ------------------ EVALUATION PAGE ------------------
@staff_member_required
def evaluation_page(request):
    """
    Admin page to evaluate teams.
    Disqualified teams' inputs are disabled automatically.
    """
    teams = Team.objects.all()
    criteria_fields = ["presentation", "communication", "teamwork", "improvement"]

    # ---------- SAVE ----------
    if request.method == 'POST':
        team_id = request.POST.get('team_id')

        if not team_id:
            messages.error(request, "⚠️ Team ID missing in submission.")
            return redirect('evaluation_page')

        try:
            team = Team.objects.get(id=team_id)
        except Team.DoesNotExist:
            messages.error(request, "⚠️ Team not found.")
            return redirect('evaluation_page')

        # ⛔ Prevent saving for disqualified teams
        if not team.qualified:
            messages.error(request, f"🚫 {team.team_name} is disqualified — evaluation disabled.")
            return redirect('evaluation_page')

        # Safe int conversion
        def safe_int(value):
            try:
                return int(value)
            except (TypeError, ValueError):
                return 0

        update_data = {}

        for week in range(1, 6):
            week_sum = 0
            for field in criteria_fields:
                key = f"week{week}_{field}"
                val = safe_int(request.POST.get(key, 0))
                update_data[key] = val
                week_sum += val

            feedback_key = f"week{week}_feedback"
            update_data[feedback_key] = request.POST.get(feedback_key, "")
            update_data[f"week{week}_total"] = week_sum

        update_data["overall_feedback"] = request.POST.get("overall_feedback", "")
        total_score = sum(update_data.get(f"week{week}_total", 0) for week in range(1, 6))
        update_data["score"] = total_score

        Evaluation.objects.update_or_create(team=team, defaults=update_data)

        messages.success(
            request,
            f"✅ Evaluation for {team.team_name} saved successfully! (Total Score: {total_score})"
        )
        return redirect('evaluation_page')

    # ---------- LOAD ----------
    team_evaluations = []
    for team in teams:
        eval_obj = Evaluation.objects.filter(team=team).first()
        eval_data = {}

        if eval_obj:
            for week in range(1, 6):
                for field in criteria_fields:
                    eval_data[f"week{week}_{field}"] = getattr(eval_obj, f"week{week}_{field}", 0)
                eval_data[f"week{week}_feedback"] = getattr(eval_obj, f"week{week}_feedback", "")
                eval_data[f"week{week}_total"] = getattr(eval_obj, f"week{week}_total", 0)
            eval_data["overall_feedback"] = getattr(eval_obj, "overall_feedback", "")
            eval_data["score"] = getattr(eval_obj, "score", 0)
        else:
            for week in range(1, 6):
                for field in criteria_fields:
                    eval_data[f"week{week}_{field}"] = 0
                eval_data[f"week{week}_feedback"] = ""
                eval_data[f"week{week}_total"] = 0
            eval_data["overall_feedback"] = ""
            eval_data["score"] = 0

        team_evaluations.append({
            "team": team,
            "evaluation": eval_data,
        })

    context = {
        "team_evaluations": team_evaluations,
        "criteria_fields": criteria_fields,
    }

    return render(request, "evaluation_page.html", context)
