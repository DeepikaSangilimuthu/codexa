# Create your views here.
from django.shortcuts import render,redirect
from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Sum, Count
from .models import Team,Participant,Attendance,Submission,Evaluation

def home(request):
    return render(request, 'home.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # 🧠 Admin login check
        if username == 'admin' and password == 'admin123':
            return redirect('admin_dashboard')

        # 🧠 Team login check (verify from DB)
        try:
            team = Team.objects.get(team_name=username, password=password)
            return redirect('team_dashboard', team_name=team.team_name)
        except Team.DoesNotExist:
            messages.error(request, "Invalid credentials. Please try again.")

    return render(request, 'login.html')

def team_dashboard(request, team_name):
    try:
        team = Team.objects.get(team_name=team_name)
    except Team.DoesNotExist:
        return redirect('login')

    # Fetch related info (optional)
    evaluations = Evaluation.objects.filter(team=team)
    submissions = Submission.objects.filter(team=team)

    context = {
        'team': team,
        'evaluations': evaluations,
        'submissions': submissions
    }
    return render(request, 'team_dashboard.html', context)


@staff_member_required
def admin_dashboard(request):
    total_teams = Team.objects.count()
    qualified = Team.objects.filter(qualified=True).count()
    disqualified = Team.objects.filter(qualified=False).count()
    submission_count = Submission.objects.count()
    
    
    # top 3 teams by total score
    teams_with_score = Team.objects.annotate(total=Sum('evaluation__score')).order_by('-total')[:3]
    # ensure total is non-null
    top3 = [{
        'name': t.team_name,
        'total_score': (t.total or 0)
    } for t in teams_with_score]

    context = {
        'total_teams': total_teams,
        'qualified': qualified,
        'disqualified': disqualified,
        'submission_count': submission_count,
        'top3': top3,
    }
    return render(request, 'admin_dashboard.html', context)


@staff_member_required
def team_management(request):
    teams = Team.objects.prefetch_related('participants').all()
    for team in teams:
        if team.project_stack:
            team.stack_list = [tech.strip() for tech in team.project_stack.split(',')]
        else:
            team.stack_list = []
    context = {'teams': teams}
    return render(request, 'team_management.html', context)

@staff_member_required
def attendance_page(request):
    # Fetch all teams with their members
    teams = Team.objects.prefetch_related('participants').all()

    if request.method == "POST":
        for team in teams:
            # Update weekly attendance from the form
            team.week1 = request.POST.get(f'week1_{team.id}', 'present')
            team.week2 = request.POST.get(f'week2_{team.id}', 'present')
            team.week3 = request.POST.get(f'week3_{team.id}', 'present')
            team.week4 = request.POST.get(f'week4_{team.id}', 'present')
            team.week5 = request.POST.get(f'week5_{team.id}', 'present')
            # Save (this automatically updates qualified status in model.save)
            team.save()

        return redirect('attendance_page')

    # Pass teams to template
    return render(request, 'attendance_page.html', {'teams': teams})

@staff_member_required
def evaluation_page(request):
    teams = Team.objects.all()

    if request.method == 'POST':
        team_id = request.POST.get('team_id')
        team = Team.objects.get(id=team_id)

        presentation = int(request.POST.get('presentation' ))
        teamwork = int(request.POST.get('teamwork' ))
        communication = int(request.POST.get('communication' ))
        improvement = int(request.POST.get('improvement'))
        feedback = request.POST.get('feedback', '')

        Evaluation.objects.update_or_create(
            team=team,
            defaults={
                'presentation': presentation,
                'teamwork': teamwork,
                'communication': communication,
                'improvement': improvement,
                'feedback': feedback,
            }
        )

        return redirect('evaluation_page')

    context = {'teams': teams}
    return render(request, 'evaluation_page.html', context)
