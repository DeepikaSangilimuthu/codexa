from django.contrib import admin
from .models import Team, Participant, Evaluation, Attendance, Submission


# ------------------ Participant Inline ------------------
class ParticipantInline(admin.TabularInline):
    model = Participant
    extra = 2
    max_num = 5


# ------------------ Attendance Inline ------------------
class AttendanceInline(admin.TabularInline):
    model = Attendance
    extra = 0
    fields = ("week", "is_present")
    readonly_fields = ("week",)
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False


# ------------------ Team Admin ------------------
@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    inlines = [ParticipantInline, AttendanceInline]
    list_display = (
        "team_number",
        "team_name",
        "project_title",
        "problem_statement",
        "project_stack",
        "qualified",
        "get_total_score",
        "get_absent_weeks",
    )
    search_fields = ("team_name", "project_title")
    list_filter = ("qualified",)

    def get_total_score(self, obj):
        evaluation = obj.evaluation.first()
        return evaluation.score if evaluation else 0
    get_total_score.short_description = "Total Score"

    def get_absent_weeks(self, obj):
        absents = obj.attendances.filter(is_present=False)
        if absents.exists():
            return ", ".join([f"Week {a.week}" for a in absents])
        return "None"
    get_absent_weeks.short_description = "Absent Weeks"


# ------------------ Evaluation Admin ------------------
@admin.register(Evaluation)
class EvaluationAdmin(admin.ModelAdmin):
    list_display = ("team", "score", "overall_feedback")
    search_fields = ("team__team_name",)
    list_filter = ("team__qualified",)
    readonly_fields = ("score",)

    fieldsets = (
        ("Team Info", {"fields": ("team",)}),
        ("Week 1 Evaluation", {
            "fields": (
                "week1_presentation", "week1_communication", "week1_teamwork",
                "week1_improvement", "week1_feedback", "week1_total"
            ),
            "classes": ("collapse",)
        }),
        ("Week 2 Evaluation", {
            "fields": (
                "week2_presentation", "week2_communication", "week2_teamwork",
                "week2_improvement", "week2_feedback", "week2_total"
            ),
            "classes": ("collapse",)
        }),
        ("Week 3 Evaluation", {
            "fields": (
                "week3_presentation", "week3_communication", "week3_teamwork",
                "week3_improvement", "week3_feedback", "week3_total"
            ),
            "classes": ("collapse",)
        }),
        ("Week 4 Evaluation", {
            "fields": (
                "week4_presentation", "week4_communication", "week4_teamwork",
                "week4_improvement", "week4_feedback", "week4_total"
            ),
            "classes": ("collapse",)
        }),
        ("Week 5 Evaluation", {
            "fields": (
                "week5_presentation", "week5_communication", "week5_teamwork",
                "week5_improvement", "week5_feedback", "week5_total"
            ),
            "classes": ("collapse",)
        }),
        ("Final Evaluation", {"fields": ("overall_feedback", "score")}),
    )


# ------------------ Attendance Admin (FIXED) ------------------
@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    """
    Show one row per TEAM in Admin instead of one per WEEK.
    Displays attendance summary and qualification.
    """
    list_display = ("team", "get_present_weeks", "get_absent_weeks", "get_status")
    search_fields = ("team__team_name",)
    ordering = ("team__team_number",)

    def get_queryset(self, request):
        """
        Fetch unique teams instead of showing every week separately.
        """
        qs = super().get_queryset(request)
        # Return one record per team by grouping
        team_ids = qs.values_list("team", flat=True).distinct()
        return qs.filter(week=1, team__in=team_ids)  # week=1 ensures 1 row per team

    def get_present_weeks(self, obj):
        count = Attendance.objects.filter(team=obj.team, is_present=True).count()
        return f"{count} / 5"
    get_present_weeks.short_description = "Weeks Present"

    def get_absent_weeks(self, obj):
        absents = Attendance.objects.filter(team=obj.team, is_present=False)
        if not absents.exists():
            return "None"
        return ", ".join([f"W{a.week}" for a in absents])
    get_absent_weeks.short_description = "Absent Weeks"

    def get_status(self, obj):
        team = obj.team
        return "✅ Qualified" if team.qualified else "🚫 Disqualified"
    get_status.short_description = "Qualification Status"


# ------------------ Submission Admin ------------------
@admin.register(Submission)
class SubmissionAdmin(admin.ModelAdmin):
    list_display = ("team", "project_link", "submitted_at")
    search_fields = ("team__team_name",)
    list_filter = ("submitted_at",)
