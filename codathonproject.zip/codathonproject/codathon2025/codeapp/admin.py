from django.contrib import admin
from .models import Team, Participant, Evaluation, Attendance

# Inline for participants under each team
class ParticipantInline(admin.TabularInline):
    model = Participant
    extra = 5  # show 5 empty rows by default
    max_num = 5  # maximum participants allowed

# Team admin with participant inline
@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    inlines = [ParticipantInline]
    list_display = ('team_number', 'team_name', 'project_title','problem_statement', 'project_stack','github_link','qualified')
    search_fields = ('team_name', 'project_title')

# Evaluation admin
# @admin.register(Evaluation)
# class EvaluationAdmin(admin.ModelAdmin):
#     list_display = ('team', 'score')
#     search_fields = ('team__team_name',)

# Attendance admin
@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ('team', 'is_present')
    list_filter = ('is_present',)
    search_fields = ('team__team_name',)
