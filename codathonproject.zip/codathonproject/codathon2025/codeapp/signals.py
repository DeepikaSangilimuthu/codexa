from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Participant, Team

@receiver(post_save, sender=Participant)
def update_team_qualification_on_attendance(sender, instance, **kwargs):
    """
    If any participant for a team is present==False, the team becomes disqualified.
    If all participants are present, team becomes qualified.
    """
    team = instance.team
    # If any participant has present=False => disqualify
    any_absent = team.participants.filter(present=False).exists()
    if any_absent:
        if team.qualified:
            team.qualified = False
            team.save(update_fields=['qualified'])
    else:
        if not team.qualified:
            team.qualified = True
            team.save(update_fields=['qualified'])