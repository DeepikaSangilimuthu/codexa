from django.db import models

# ------------------ TEAM ------------------
class Team(models.Model):
    team_number = models.IntegerField()
    team_name = models.CharField(max_length=100)
    team_count = models.IntegerField(default=1)
    project_title = models.CharField(max_length=150)
    problem_statement = models.CharField(max_length=150)
    project_stack = models.CharField(max_length=150)
    github_link = models.CharField(max_length=150)
    password = models.CharField(max_length=50)
    qualified = models.BooleanField(default=True)

    # Attendance tracking fields for each week
    week1 = models.CharField(max_length=10, default='present')
    week2 = models.CharField(max_length=10, default='present')
    week3 = models.CharField(max_length=10, default='present')
    week4 = models.CharField(max_length=10, default='present')
    week5 = models.CharField(max_length=10, default='present')

    def save(self, *args, **kwargs):
        """
        Automatically disqualify a team if any week is marked 'absent'.
        """
        if 'absent' in [self.week1, self.week2, self.week3, self.week4, self.week5]:
            self.qualified = False
        else:
            self.qualified = True
        super().save(*args, **kwargs)

    def __str__(self):
        return self.team_name


# ------------------ PARTICIPANT ------------------
class Participant(models.Model):
    team = models.ForeignKey('Team', on_delete=models.CASCADE, related_name='participants')
    name = models.CharField(max_length=100)
    role = models.CharField(max_length=50)
    contact = models.CharField(max_length=150)

    def __str__(self):
        return self.name


# ------------------ ATTENDANCE ------------------
class Attendance(models.Model):
    """
    Optional: Detailed attendance record if needed.
    """
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='attendances')
    is_present = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.team.team_name} - {'Present' if self.is_present else 'Absent'}"


# ------------------ EVALUATION ------------------
class Evaluation(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='evaluation')

    # Weekly scores
    week1 = models.IntegerField(default=0)
    week2 = models.IntegerField(default=0)
    week3 = models.IntegerField(default=0)
    week4 = models.IntegerField(default=0)
    week5 = models.IntegerField(default=0)

    # Additional feedback
    feedback = models.TextField(blank=True, null=True)

    # Total or average score (auto-calculated)
    score = models.FloatField(default=0)

    def save(self, *args, **kwargs):
        """
        Automatically calculate the total score before saving.
        (Each week is scored 0–10, so total is out of 50. We multiply by 2 for a 100 scale.)
        """
        total_weeks = self.week1 + self.week2 + self.week3 + self.week4 + self.week5
        self.score = total_weeks * 2  # Scale to 100
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.team.team_name} - {self.score}"


# ------------------ SUBMISSION ------------------
class Submission(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='submissions')
    project_link = models.URLField()
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.team.team_name} - {self.project_link}"
