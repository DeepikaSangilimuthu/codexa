from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.validators import MinValueValidator, MaxValueValidator


# ------------------ TEAM ------------------
class Team(models.Model):
    """
    Represents a participating team.
    Tracks project details, attendance, and qualification status.
    """
    team_number = models.IntegerField(unique=True)
    team_name = models.CharField(max_length=100, unique=True)
    team_count = models.IntegerField(default=1)
    project_title = models.CharField(max_length=150)
    problem_statement = models.CharField(max_length=150)
    project_stack = models.CharField(max_length=150)
    github_link = models.CharField(max_length=150)
    password = models.CharField(max_length=50)
    qualified = models.BooleanField(default=True)
    disqualification_reason = models.TextField(blank=True, null=True)

    def update_qualification(self, save_to_db=True):
        """
        Update qualification based on attendance.
        A team is disqualified if absent in any week.
        """
        absents = self.attendances.filter(is_present=False)
        if absents.exists():
            absent_weeks = [f"Week {a.week}" for a in absents]
            self.qualified = False
            self.disqualification_reason = f"Absent in {', '.join(absent_weeks)}."
        else:
            self.qualified = True
            self.disqualification_reason = ""

        if save_to_db:
            self.save(update_fields=["qualified", "disqualification_reason"])

    def __str__(self):
        return f"{self.team_name} (Team #{self.team_number})"

    class Meta:
        ordering = ["team_number"]
        verbose_name = "Team"
        verbose_name_plural = "Teams"


# ------------------ PARTICIPANT ------------------
class Participant(models.Model):
    """Stores individual participant details for each team."""
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='participants')
    name = models.CharField(max_length=100)
    role = models.CharField(max_length=50)
    contact = models.CharField(max_length=150)

    def __str__(self):
        return f"{self.name} ({self.role})"

    class Meta:
        verbose_name = "Participant"
        verbose_name_plural = "Participants"


# ------------------ ATTENDANCE ------------------
class Attendance(models.Model):
    """
    Tracks weekly attendance of teams (Week 1 to 5).
    Each team will have one record per week.
    """
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='attendances')
    week = models.PositiveIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])  # Week number (1–5)
    is_present = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        """
        Save attendance record cleanly — 
        Qualification update is intentionally handled by the view or by calling
        Team.update_qualification() explicitly to avoid multiple DB writes during bulk operations.
        """
        super().save(*args, **kwargs)

    def __str__(self):
        status = "Present" if self.is_present else "Absent"
        return f"{self.team.team_name} - Week {self.week}: {status}"

    class Meta:
        verbose_name = "Attendance"
        verbose_name_plural = "Attendances"
        unique_together = ("team", "week")  # prevent duplicate week records
        ordering = ["team__team_number", "week"]


# ------------------ EVALUATION ------------------
class Evaluation(models.Model):
    """
    Stores detailed weekly evaluation for each team.
    """
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='evaluation')

    # ---------- Week 1 ----------
    week1_presentation = models.IntegerField(default=0)
    week1_communication = models.IntegerField(default=0)
    week1_teamwork = models.IntegerField(default=0)
    week1_improvement = models.IntegerField(default=0)
    week1_feedback = models.TextField(blank=True, null=True)
    week1_total = models.IntegerField(default=0)

    # ---------- Week 2 ----------
    week2_presentation = models.IntegerField(default=0)
    week2_communication = models.IntegerField(default=0)
    week2_teamwork = models.IntegerField(default=0)
    week2_improvement = models.IntegerField(default=0)
    week2_feedback = models.TextField(blank=True, null=True)
    week2_total = models.IntegerField(default=0)

    # ---------- Week 3 ----------
    week3_presentation = models.IntegerField(default=0)
    week3_communication = models.IntegerField(default=0)
    week3_teamwork = models.IntegerField(default=0)
    week3_improvement = models.IntegerField(default=0)
    week3_feedback = models.TextField(blank=True, null=True)
    week3_total = models.IntegerField(default=0)

    # ---------- Week 4 ----------
    week4_presentation = models.IntegerField(default=0)
    week4_communication = models.IntegerField(default=0)
    week4_teamwork = models.IntegerField(default=0)
    week4_improvement = models.IntegerField(default=0)
    week4_feedback = models.TextField(blank=True, null=True)
    week4_total = models.IntegerField(default=0)

    # ---------- Week 5 ----------
    week5_presentation = models.IntegerField(default=0)
    week5_communication = models.IntegerField(default=0)
    week5_teamwork = models.IntegerField(default=0)
    week5_improvement = models.IntegerField(default=0)
    week5_feedback = models.TextField(blank=True, null=True)
    week5_total = models.IntegerField(default=0)

    # ---------- Overall ----------
    overall_feedback = models.TextField(blank=True, null=True)
    score = models.FloatField(default=0)

    def calculate_totals(self):
        """Automatically calculate weekly totals and overall score."""
        for week in range(1, 6):
            total = (
                getattr(self, f"week{week}_presentation", 0)
                + getattr(self, f"week{week}_communication", 0)
                + getattr(self, f"week{week}_teamwork", 0)
                + getattr(self, f"week{week}_improvement", 0)
            )
            setattr(self, f"week{week}_total", total)
        self.score = sum(getattr(self, f"week{w}_total") for w in range(1, 6))

    def save(self, *args, **kwargs):
        """Prevent scoring if the team is disqualified."""
        if self.team and not self.team.qualified:
            self.score = 0
            self.overall_feedback = (
                self.overall_feedback or "Team disqualified — evaluation not applicable."
            )
        else:
            self.calculate_totals()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.team.team_name} — {self.score}"

    class Meta:
        verbose_name = "Evaluation"
        verbose_name_plural = "Evaluations"
        ordering = ["team__team_number"]


# ------------------ SUBMISSION ------------------
class Submission(models.Model):
    """Tracks project submissions for each team."""
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='submissions')
    project_link = models.URLField()
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.team.team_name} — {self.project_link}"

    class Meta:
        verbose_name = "Submission"
        verbose_name_plural = "Submissions"


# ------------------ SIGNAL: AUTO-CREATE ATTENDANCE ------------------
@receiver(post_save, sender=Team)
def create_team_attendance(sender, instance, created, **kwargs):
    """
    Ensure every team automatically gets attendance records for Weeks 1–5 after creation.
    Placed after Attendance model definition so Attendance is available at import time.
    """
    if created:
        for week in range(1, 6):
            Attendance.objects.get_or_create(team=instance, week=week)
