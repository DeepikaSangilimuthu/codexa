from django.db import models
class Team(models.Model):
    team_number = models.IntegerField()
    team_name = models.CharField(max_length=100)
    team_count = models.IntegerField(default=1)
    project_title = models.CharField(max_length=150)
    problem_statement = models.CharField(max_length=150)
    project_stack = models.CharField(max_length=150)
    github_link = models.CharField(max_length=150)
    password = models.CharField(max_length=50)
    qualified = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        """
        Automatically disqualify a team if any week is marked 'absent'.
        """
        if 'absent' in [self.week1, self.week2, self.week3, self.week4, self.week5]:
            self.qualified = False
        else:
            self.qualified = True
        super().save(*args, **kwargs)

    def __str__(self):
        return self.team_name

# ------------------ PARTICIPANT ------------------
class Participant(models.Model):
    team = models.ForeignKey('Team', on_delete=models.CASCADE, related_name='participants')
    name = models.CharField(max_length=100)
    role = models.CharField(max_length=50)
    contact = models.CharField(max_length=150)

    def __str__(self):
        return self.name

# ------------------ ATTENDANCE ------------------
class Attendance(models.Model):
    """
    Optional: Detailed attendance record if needed.
    """
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='attendances')
    is_present = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.team.team_name} - {'Present' if self.is_present else 'Absent'}"

# ------------------ EVALUATION ------------------
class Evaluation(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='evaluation')
    presentation = models.IntegerField(default=0)
    teamwork = models.IntegerField(default=0)
    communication = models.IntegerField(default=0)
    improvement = models.IntegerField(default=0)
    feedback = models.TextField(blank=True, null=True)
    score = models.FloatField(default=0)

    def save(self, *args, **kwargs):
        """
        Automatically calculate overall score before saving.
        """
        self.score = (self.presentation + self.teamwork + self.communication + self.improvement) * 2.5
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.team.team_name} - {self.score}"

# ------------------ SUBMISSION ------------------
class Submission(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='submissions')
    project_link = models.URLField()
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.team.team_name} - {self.project_link}"
