from django.db import models


# ------------------ TEAM ------------------
class Team(models.Model):
    team_number = models.IntegerField()
    team_name = models.CharField(max_length=100)
    team_count = models.IntegerField(default=1)
    project_title = models.CharField(max_length=150)
    problem_statement = models.CharField(max_length=150)
    project_stack = models.CharField(max_length=150)
    github_link = models.CharField(max_length=150)
    password = models.CharField(max_length=50)
    qualified = models.BooleanField(default=True)

    # Attendance tracking
    week1 = models.CharField(max_length=10, default='present')
    week2 = models.CharField(max_length=10, default='present')
    week3 = models.CharField(max_length=10, default='present')
    week4 = models.CharField(max_length=10, default='present')
    week5 = models.CharField(max_length=10, default='present')

    disqualification_reason = models.TextField(blank=True, null=True)

    def save(self, *args, **kwargs):
        """
        Automatically mark as disqualified if absent in any week.
        Records reason for disqualification.
        """
        absent_weeks = [
            week for week, status in [
                ("Week 1", self.week1),
                ("Week 2", self.week2),
                ("Week 3", self.week3),
                ("Week 4", self.week4),
                ("Week 5", self.week5),
            ] if status.lower() == 'absent'
        ]

        if absent_weeks:
            self.qualified = False
            self.disqualification_reason = f"Absent in {', '.join(absent_weeks)}."
        else:
            self.qualified = True
            self.disqualification_reason = ""

        super().save(*args, **kwargs)

    @property
    def is_disqualified(self):
        """Return True if team is not qualified."""
        return not self.qualified

    def __str__(self):
        return f"{self.team_name} (#{self.team_number})"


# ------------------ PARTICIPANT ------------------
class Participant(models.Model):
    team = models.ForeignKey('Team', on_delete=models.CASCADE, related_name='participants')
    name = models.CharField(max_length=100)
    role = models.CharField(max_length=50)
    contact = models.CharField(max_length=150)

    def __str__(self):
        return f"{self.name} ({self.role})"


# ------------------ ATTENDANCE ------------------
class Attendance(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='attendances')
    week = models.PositiveIntegerField(default=1)
    is_present = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.team.team_name} - Week {self.week}: {'Present' if self.is_present else 'Absent'}"


# ------------------ EVALUATION ------------------
class Evaluation(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='evaluation')

    # ---------- Week 1 ----------
    week1_presentation = models.IntegerField(default=0)
    week1_communication = models.IntegerField(default=0)
    week1_teamwork = models.IntegerField(default=0)
    week1_improvement = models.IntegerField(default=0)
    week1_feedback = models.TextField(blank=True, null=True)
    week1_total = models.IntegerField(default=0)

    # ---------- Week 2 ----------
    week2_presentation = models.IntegerField(default=0)
    week2_communication = models.IntegerField(default=0)
    week2_teamwork = models.IntegerField(default=0)
    week2_improvement = models.IntegerField(default=0)
    week2_feedback = models.TextField(blank=True, null=True)
    week2_total = models.IntegerField(default=0)

    # ---------- Week 3 ----------
    week3_presentation = models.IntegerField(default=0)
    week3_communication = models.IntegerField(default=0)
    week3_teamwork = models.IntegerField(default=0)
    week3_improvement = models.IntegerField(default=0)
    week3_feedback = models.TextField(blank=True, null=True)
    week3_total = models.IntegerField(default=0)

    # ---------- Week 4 ----------
    week4_presentation = models.IntegerField(default=0)
    week4_communication = models.IntegerField(default=0)
    week4_teamwork = models.IntegerField(default=0)
    week4_improvement = models.IntegerField(default=0)
    week4_feedback = models.TextField(blank=True, null=True)
    week4_total = models.IntegerField(default=0)

    # ---------- Week 5 ----------
    week5_presentation = models.IntegerField(default=0)
    week5_communication = models.IntegerField(default=0)
    week5_teamwork = models.IntegerField(default=0)
    week5_improvement = models.IntegerField(default=0)
    week5_feedback = models.TextField(blank=True, null=True)
    week5_total = models.IntegerField(default=0)

    # ---------- Overall Feedback ----------
    overall_feedback = models.TextField(blank=True, null=True)

    # ---------- Final Overall Score ----------
    score = models.FloatField(default=0)

    def calculate_totals(self):
        """Calculate weekly totals and final score."""
        self.week1_total = (
            self.week1_presentation + self.week1_communication +
            self.week1_teamwork + self.week1_improvement
        )
        self.week2_total = (
            self.week2_presentation + self.week2_communication +
            self.week2_teamwork + self.week2_improvement
        )
        self.week3_total = (
            self.week3_presentation + self.week3_communication +
            self.week3_teamwork + self.week3_improvement
        )
        self.week4_total = (
            self.week4_presentation + self.week4_communication +
            self.week4_teamwork + self.week4_improvement
        )
        self.week5_total = (
            self.week5_presentation + self.week5_communication +
            self.week5_teamwork + self.week5_improvement
        )

        self.score = (
            self.week1_total + self.week2_total +
            self.week3_total + self.week4_total +
            self.week5_total
        )

    def save(self, *args, **kwargs):
        """
        Prevent saving evaluation if the team is disqualified.
        Otherwise calculate totals automatically.
        """
        if self.team and not self.team.qualified:
            # If team is disqualified, prevent scoring update
            self.score = 0
            self.overall_feedback = (
                self.overall_feedback or
                "Team disqualified — evaluation not applicable."
            )
        else:
            self.calculate_totals()

        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.team.team_name} - {self.score}"


# ------------------ SUBMISSION ------------------
class Submission(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='submissions')
    project_link = models.URLField()
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.team.team_name} - {self.project_link}"
