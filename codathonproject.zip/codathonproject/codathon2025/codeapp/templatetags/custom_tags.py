from django import template

register = template.Library()

@register.filter
def get_item(value, key):
    """
    Safely fetches a value from a dictionary or object using a key.
    This filter supports nested dictionary access in templates:
      {{ data|get_item:"key" }}
      {{ data|get_item:some_id|get_item:"week" }}
    Returns an empty string ("") if the key is missing.
    """
    try:
        if value is None or key is None:
            return ""

        # If it's a dictionary
        if isinstance(value, dict):
            return value.get(str(key), "")

        # If it's an object (fallback)
        return getattr(value, str(key), "")
    except Exception:
        return ""


@register.filter
def to(value, end):
    """
    Custom range filter for Django templates.
    Allows looping with a numeric range directly in the template.

    Example:
        {% for i in 1|to:6 %}
            Week {{ i }}
        {% endfor %}

    This will iterate: 1, 2, 3, 4, 5
    """
    try:
        start = int(value)
        stop = int(end)
        return range(start, stop)
    except Exception:
        return []
