from django import template

register = template.Library()

@register.filter
def get_item(obj, key):
    """
    Safely get an item or attribute from a dict or object in Django templates.
    Supports nested keys separated by dots (e.g., 'evaluation.score').
    Example usage:
      {{ team|get_item:"team_name" }}
      {{ eval|get_item:"week1_feedback" }}
      {{ obj|get_item:"evaluation.score" }}
    """
    try:
        # Handle None or invalid input
        if obj is None or key is None:
            return ""

        # Support nested access like "evaluation.score"
        keys = str(key).split('.')
        value = obj

        for k in keys:
            if isinstance(value, dict):
                value = value.get(k, "")
            else:
                value = getattr(value, k, "")

        return value
    except Exception:
        return ""
