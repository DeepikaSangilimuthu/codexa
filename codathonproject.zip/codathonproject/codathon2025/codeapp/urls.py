from django.urls import path
from . import views

urlpatterns = [
    path('',views.home,name='home'),
    path('login/', views.login_view, name='login'),
    path('team_dashboard/<str:team_name>/', views.team_dashboard, name='team_dashboard'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('team-management/', views.team_management, name='team_management'),
    path('attendance/', views.attendance_page, name='attendance_page'),
    path('evaluation/', views.evaluation_page, name='evaluation_page'),
  
]