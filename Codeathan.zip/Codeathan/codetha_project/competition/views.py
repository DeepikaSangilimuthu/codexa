from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from .models import Team, Attendance, Evaluation
from .forms import TeamForm, AttendanceForm, EvaluationForm

# ---- Admin simple pages (protected by staff_member_required) ----

@staff_member_required
def admin_team_list(request):
    teams = Team.objects.all()
    return render(request, 'admin_team_list.html', {'teams': teams})

@staff_member_required
def admin_add_team(request):
    if request.method == 'POST':
        form = TeamForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Team added.")
            return redirect('admin_team_list')
    else:
        form = TeamForm()
    return render(request, 'admin_add_team.html', {'form': form})

@staff_member_required
def admin_attendance(request, team_id=None):
    if request.method == 'POST':
        form = AttendanceForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Attendance saved.")
            if team_id:
                return redirect('admin_attendance', team_id=team_id)
            return redirect('admin_team_list')
    else:
        if team_id:
            team = get_object_or_404(Team, id=team_id)
            form = AttendanceForm(initial={'team': team})
        else:
            form = AttendanceForm()
    return render(request, 'admin_attendance.html', {'form': form})

@staff_member_required
def admin_evaluate(request, team_id=None):
    if request.method == 'POST':
        form = EvaluationForm(request.POST)
        if form.is_valid():
            ev = form.save(commit=False)
            ev.evaluator = request.user
            ev.save()
            messages.success(request, "Evaluation saved.")
            return redirect('admin_team_list')
    else:
        if team_id:
            team = get_object_or_404(Team, id=team_id)
            form = EvaluationForm(initial={'team': team})
        else:
            form = EvaluationForm()
    return render(request, 'admin_evaluate.html', {'form': form})

# ---- Student (team) login & dashboard ----

def student_login(request):
    if request.method == 'POST':
        team_name = request.POST.get('team_name')
        password = request.POST.get('password')
        try:
            team = Team.objects.get(team_name=team_name)
        except Team.DoesNotExist:
            messages.error(request, "Team not found.")
            return redirect('student_login')

        if team.check_password(password):
            # store team id in session
            request.session['team_id'] = team.id
            return redirect('student_dashboard')
        else:
            messages.error(request, "Invalid credentials.")
            return redirect('student_login')

    return render(request, 'student_login.html')

def student_logout(request):
    request.session.pop('team_id', None)
    messages.info(request, "Logged out.")
    return redirect('student_login')

def student_dashboard(request):
    team_id = request.session.get('team_id')
    if not team_id:
        messages.info(request, "Please login.")
        return redirect('student_login')
    team = get_object_or_404(Team, id=team_id)
    attendances = team.attendances.all().order_by('week')
    evaluations = team.evaluations.all().order_by('week')
    context = {
        'team': team,
        'attendances': attendances,
        'evaluations': evaluations,
        'competition_status': team.competition_status(),
    }
    return render(request, 'student_dashboard.html', context)
