from django import forms
from .models import Team, Attendance, Evaluation

class TeamForm(forms.ModelForm):
    raw_password = forms.CharField(widget=forms.PasswordInput, label="Team Password")

    class Meta:
        model = Team
        fields = ['team_number', 'team_name', 'member_count', 'members', 'contact_number', 'tutor_name', 'project_name', 'photo']

    def save(self, commit=True):
        instance = super().save(commit=False)
        raw = self.cleaned_data.get('raw_password')
        if raw:
            instance.set_password(raw)
        if commit:
            instance.save()
        return instance

class AttendanceForm(forms.ModelForm):
    class Meta:
        model = Attendance
        fields = ['team', 'week', 'all_present', 'note']

class EvaluationForm(forms.ModelForm):
    class Meta:
        model = Evaluation
        fields = ['team', 'week', 'presentation', 'coordination', 'ui_design', 'efficiency', 'suggestion']
