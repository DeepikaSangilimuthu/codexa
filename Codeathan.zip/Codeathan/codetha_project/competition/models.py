from django.db import models
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth import get_user_model

WEEKS = [(i, f"Week {i}") for i in range(1, 6)]

class Team(models.Model):
    team_number = models.PositiveIntegerField(unique=True)
    team_name = models.CharField(max_length=100, unique=True)
    member_count = models.PositiveSmallIntegerField(choices=[(i, str(i)) for i in range(1, 6)])
    members = models.TextField(help_text='Comma-separated member names')
    contact_number = models.CharField(max_length=20)
    tutor_name = models.CharField(max_length=100, blank=True)
    project_name = models.CharField(max_length=255)
    photo = models.ImageField(upload_to='team_photos/', blank=True, null=True)
    password = models.CharField(max_length=128)  # hashed
    created_at = models.DateTimeField(auto_now_add=True)
    is_disqualified = models.BooleanField(default=False)

    class Meta:
        ordering = ['team_number']

    def __str__(self):
        return f"{self.team_name} ({self.team_number})"

    def set_password(self, raw_password):
        """Hash and set password."""
        self.password = make_password(raw_password)

    def check_password(self, raw_password):
        """Return True if password matches."""
        return check_password(raw_password, self.password)

    def competition_status(self):
        """
        Returns one of: 'Disqualified', 'Completed', 'In Progress'
        Logic:
        - If is_disqualified True -> Disqualified
        - If all 5 weeks have attendance records and all_present True -> Completed
        - Otherwise -> In Progress
        """
        if self.is_disqualified:
            return "Disqualified"

        weeks = Attendance.objects.filter(team=self)
        if weeks.count() == 5 and all(a.all_present for a in weeks.order_by('week')):
            return "Completed"
        return "In Progress"

class Attendance(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='attendances')
    week = models.PositiveSmallIntegerField(choices=WEEKS)
    all_present = models.BooleanField(default=True, help_text="Check if all team members were present this week")
    note = models.CharField(max_length=255, blank=True)

    class Meta:
        unique_together = ('team', 'week')
        ordering = ['team', 'week']

    def __str__(self):
        return f"{self.team} - Week {self.week} - {'Present' if self.all_present else 'Absent/Some absent'}"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        # If this week is not all_present, mark team disqualified
        if not self.all_present:
            if not self.team.is_disqualified:
                self.team.is_disqualified = True
                self.team.save(update_fields=['is_disqualified'])

class Evaluation(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='evaluations')
    week = models.PositiveSmallIntegerField(choices=WEEKS)
    presentation = models.PositiveSmallIntegerField(default=0)
    coordination = models.PositiveSmallIntegerField(default=0)
    ui_design = models.PositiveSmallIntegerField(default=0)
    efficiency = models.PositiveSmallIntegerField(default=0)
    suggestion = models.TextField(blank=True)
    evaluator = models.ForeignKey(get_user_model(), null=True, blank=True, on_delete=models.SET_NULL)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('team', 'week')
        ordering = ['team', 'week']

    def __str__(self):
        return f"Eval: {self.team} - Week {self.week}"

    @property
    def total_marks(self):
        return self.presentation + self.coordination + self.ui_design + self.efficiency
