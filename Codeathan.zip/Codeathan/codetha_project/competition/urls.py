from django.urls import path
from . import views

urlpatterns = [
    # Student section
    path('student/login/', views.student_login, name='student_login'),
    path('student/logout/', views.student_logout, name='student_logout'),
    path('student/dashboard/', views.student_dashboard, name='student_dashboard'),

    # Custom Admin (Competition Panel)
    path('', views.admin_team_list, name='admin_team_list'),
    path('panel/teams/add/', views.admin_add_team, name='admin_add_team'),
    path('panel/attendance/', views.admin_attendance, name='admin_attendance'),
    path('panel/attendance/<int:team_id>/', views.admin_attendance, name='admin_attendance_team'),
    path('panel/evaluate/', views.admin_evaluate, name='admin_evaluate'),
    path('panel/evaluate/<int:team_id>/', views.admin_evaluate, name='admin_evaluate_team'),
]
