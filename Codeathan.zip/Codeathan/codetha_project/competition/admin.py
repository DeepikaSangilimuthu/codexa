from django.contrib import admin
from .models import Team, Attendance, Evaluation

@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    list_display = ('team_number', 'team_name', 'member_count', 'project_name', 'is_disqualified')
    search_fields = ('team_name', 'project_name')
    list_filter = ('is_disqualified',)

@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ('team', 'week', 'all_present')
    list_filter = ('week', 'all_present')
    search_fields = ('team__team_name',)

@admin.register(Evaluation)
class EvaluationAdmin(admin.ModelAdmin):
    list_display = ('team', 'week', 'total_marks', 'evaluator', 'created_at')
    readonly_fields = ('total_marks',)
